package com.relaytunnel.app

import android.content.Context
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject

/** پوشش ساده روی ماژول پایتونی sp_client برای صدا زدن راحت‌تر از Kotlin. */
object PyBridge {
    private lateinit var module: PyObject

    @Synchronized
    fun init(ctx: Context) {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(ctx))
        }
        val py = Python.getInstance()
        // پوشه‌ی خصوصی اپ برای ذخیره‌ی session و فایل‌های موقت فریم‌ها
        py.getModule("os").callAttr("environ").callAttr(
            "__setitem__", "RELAY_FILES_DIR", ctx.filesDir.absolutePath
        )
        module = py.getModule("sp_client")
    }

    fun sendCode(phone: String): JSONObject =
        JSONObject(module.callAttr("send_code", phone).toString())

    fun signIn(code: String, password: String = ""): JSONObject =
        JSONObject(module.callAttr("sign_in", code, password).toString())

    fun isLoggedIn(): Boolean = module.callAttr("is_logged_in").toBoolean()

    fun listBots(): JSONObject =
        JSONObject(module.callAttr("list_bots").toString())

    fun sendFrame(botId: String, payloadB64: String): JSONObject =
        JSONObject(module.callAttr("send_frame", botId, payloadB64).toString())

    fun poll(botId: String): JSONObject =
        JSONObject(module.callAttr("poll", botId).toString())

    fun logout() {
        module.callAttr("logout")
    }
}
