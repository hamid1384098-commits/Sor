package com.relaytunnel.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var etPhone: EditText
    private lateinit var etCode: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSendCode: Button
    private lateinit var btnSignIn: Button
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        PyBridge.init(applicationContext)

        etPhone = findViewById(R.id.etPhone)
        etCode = findViewById(R.id.etCode)
        etPassword = findViewById(R.id.etPassword)
        btnSendCode = findViewById(R.id.btnSendCode)
        btnSignIn = findViewById(R.id.btnSignIn)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)

        // اگر قبلاً لاگین کرده، مستقیم برو به مرحله‌ی بعد
        scope.launch {
            val logged = withContext(Dispatchers.IO) { PyBridge.isLoggedIn() }
            if (logged) goNext()
        }

        btnSendCode.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            if (phone.isEmpty()) { tvStatus.text = "شماره را وارد کن"; return@setOnClickListener }
            setBusy(true)
            scope.launch {
                val res = withContext(Dispatchers.IO) { PyBridge.sendCode(phone) }
                setBusy(false)
                if (res.optBoolean("ok")) {
                    tvStatus.text = "کد ارسال شد؛ داخل سروش را چک کن"
                    etCode.visibility = View.VISIBLE
                    etPassword.visibility = View.VISIBLE
                    btnSignIn.visibility = View.VISIBLE
                } else {
                    tvStatus.text = "خطا: " + res.optString("error")
                }
            }
        }

        btnSignIn.setOnClickListener {
            val code = etCode.text.toString().trim()
            val pass = etPassword.text.toString()
            setBusy(true)
            scope.launch {
                val res = withContext(Dispatchers.IO) { PyBridge.signIn(code, pass) }
                setBusy(false)
                when {
                    res.optBoolean("ok") -> goNext()
                    res.optBoolean("need_password") -> tvStatus.text = "رمز دومرحله‌ای لازم است، وارد کن و دوباره بزن"
                    else -> tvStatus.text = "خطا: " + res.optString("error")
                }
            }
        }
    }

    private fun setBusy(b: Boolean) {
        progress.visibility = if (b) View.VISIBLE else View.GONE
        btnSendCode.isEnabled = !b
        btnSignIn.isEnabled = !b
    }

    private fun goNext() {
        val target = if (Prefs.botId(this) == null) BotSelectActivity::class.java else MainActivity::class.java
        startActivity(Intent(this, target))
        finish()
    }
}
