#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
پل پایتون (زیر Chaquopy) برای ورود به حساب شخصی سروش و ارسال/دریافت فریم‌های تانل.
منطق لاگین و استفاده از کتابخانه عیناً از main19.py (SPUser) گرفته شده، چون همان‌جا
امتحان‌شده و جواب داده. اینجا فقط خروجی ساده‌تر (دیکشنری/رشته) برمی‌گردانیم چون از
سمت Kotlin (Chaquopy) صدا زده می‌شود.

هیچ تابعی موقع import اجرا نمی‌شود؛ Kotlin هر کدام را صریح صدا می‌زند.
"""
import asyncio, importlib, importlib.util, json, os, subprocess, sys, threading, time

SP_LIBS = ("nsplusthon", "splusthon", "samyarpy")

_state_lock = threading.Lock()
_loop = None
_client = None
_sp_mod = [None]
_sp_name = [None]
_phone = None
_code_hash = None


def _files_dir():
    # Chaquopy از قبل chaquopy.AndroidPlatform.files_dir را set می‌کند؛ اگر ست نشده بود cwd
    return os.environ.get("RELAY_FILES_DIR", os.getcwd())


def _session_path():
    return os.path.join(_files_dir(), "sp_session.txt")


def _load_session():
    try:
        with open(_session_path(), encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def _save_session(s):
    with open(_session_path(), "w", encoding="utf-8") as f:
        f.write(s or "")


def _digits(s):
    return (s or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def _norm_phone(raw):
    d = "".join(ch for ch in _digits(raw) if ch.isdigit())
    if d.startswith("0098"):
        d = d[2:]
    if d.startswith("98"):
        d = "+" + d
    elif d.startswith("0"):
        d = "+98" + d[1:]
    elif not d.startswith("+"):
        d = "+98" + d
    return d


def _get_loop():
    global _loop
    with _state_lock:
        if _loop is None:
            _loop = asyncio.new_event_loop()
            threading.Thread(target=_loop.run_forever, daemon=True).start()
    return _loop


def _run(coro_fn, *a, timeout=180):
    fut = asyncio.run_coroutine_threadsafe(coro_fn(*a), _get_loop())
    return fut.result(timeout)


def _ensure_lib():
    if _sp_mod[0]:
        return _sp_mod[0]
    last = None
    for name in SP_LIBS:
        try:
            if not importlib.util.find_spec(name):
                continue
            mod = importlib.import_module(name)
            sess = importlib.import_module(name + ".sessions")
            _sp_mod[0] = (mod, sess.StringSession)
            _sp_name[0] = name
            return _sp_mod[0]
        except Exception as e:
            last = e
    raise RuntimeError(f"هیچ‌کدام از کتابخانه‌های سروش نصب نیستند (pip baid nsplusthon را در build.gradle چک کنی): {last}")


def diag():
    try:
        _ensure_lib()
        return "OK: " + str(_sp_name[0])
    except Exception as e:
        return "FAIL: " + str(e)[:300]


async def _client_connected():
    global _client
    mod, SS = _ensure_lib()
    if _client is None:
        sess = SS(_load_session())
        _client = mod.SoroushClient(sess)
    if not _client.is_connected():
        await _client.connect()
    return _client


# ---------------------------------------------------------------- عمومی


async def _a_send_code(phone):
    global _phone, _code_hash
    c = await _client_connected()
    if await c.is_user_authorized():
        return json.dumps({"ok": True, "already": True})
    r = await c.send_code_request(phone)
    _phone = phone
    _code_hash = getattr(r, "phone_code_hash", None)
    return json.dumps({"ok": True, "already": False})


def send_code(phone_raw):
    try:
        return _run(_a_send_code, _norm_phone(phone_raw), timeout=240)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


async def _a_sign_in(code, password):
    c = await _client_connected()
    try:
        if password:
            await c.sign_in(password=password)
        else:
            if not _phone:
                raise RuntimeError("اول «ارسال کد» را بزن")
            kw = {"phone_code_hash": _code_hash} if _code_hash else {}
            await c.sign_in(_phone, code, **kw)
    except Exception as e:
        if type(e).__name__ == "SessionPasswordNeededError":
            return json.dumps({"ok": False, "need_password": True})
        raise
    _save_session(c.session.save())
    me = await c.get_me()
    return json.dumps({"ok": True, "user_id": str(getattr(me, "id", ""))})


def sign_in(code, password=""):
    try:
        return _run(_a_sign_in, "".join(ch for ch in _digits(code) if ch.isdigit()), password, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


async def _a_is_logged_in():
    try:
        c = await _client_connected()
        return await c.is_user_authorized()
    except Exception:
        return False


def is_logged_in():
    try:
        return bool(_run(_a_is_logged_in, timeout=60))
    except Exception:
        return False


async def _a_list_bots():
    c = await _client_connected()
    if not await c.is_user_authorized():
        raise RuntimeError("اول وارد حساب شو")
    out = []
    async for d in c.iter_dialogs(limit=300):
        ent = d.entity
        if getattr(ent, "bot", False):
            out.append({
                "id": str(d.id),
                "name": str(getattr(ent, "first_name", None) or getattr(d, "name", None) or d.id)[:60],
                "username": getattr(ent, "username", "") or "",
            })
    return json.dumps({"ok": True, "bots": out})


def list_bots():
    try:
        return _run(_a_list_bots, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


# ------------------------------------------------------------ فریم‌های تانل
# هر فریم یک خط JSON است: {"id": شمارنده صعودی، "data": base64(bytes)}
# فریم‌های کوچک به صورت پیام متنی و بزرگ‌تر از MAX_TEXT به صورت فایل txt فرستاده می‌شوند
# تا به محدودیت طول پیام سروش نخوریم.

MAX_TEXT = 3500


async def _a_send_frame(bot_id, payload_b64):
    c = await _client_connected()
    if not await c.is_user_authorized():
        raise RuntimeError("اکانت وارد نشده")
    ent = None
    async for d in c.iter_dialogs(limit=300):
        if str(d.id) == str(bot_id):
            ent = d.entity
            break
    if ent is None:
        raise RuntimeError("بات انتخابی پیدا نشد؛ دوباره انتخابش کن")
    text = payload_b64
    if len(text) <= MAX_TEXT:
        await c.send_message(ent, text)
    else:
        path = os.path.join(_files_dir(), f"out_{int(time.time()*1000)}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        try:
            await c.send_file(ent, path, force_document=True)
        finally:
            try:
                os.remove(path)
            except Exception:
                pass
    return json.dumps({"ok": True})


def send_frame(bot_id, payload_b64):
    try:
        return _run(_a_send_frame, bot_id, payload_b64, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


_last_seen_id = [0]


async def _a_poll(bot_id):
    c = await _client_connected()
    if not await c.is_user_authorized():
        raise RuntimeError("اکانت وارد نشده")
    ent = None
    async for d in c.iter_dialogs(limit=300):
        if str(d.id) == str(bot_id):
            ent = d.entity
            break
    if ent is None:
        raise RuntimeError("بات انتخابی پیدا نشد")
    out = []
    async for msg in c.iter_messages(ent, min_id=_last_seen_id[0], limit=50):
        if msg.id <= _last_seen_id[0]:
            continue
        if msg.out:
            continue  # پیام‌های خودمان (درخواست‌های ارسالی) را نادیده بگیر
        text = msg.raw_text or ""
        if (not text) and msg.document:
            local = os.path.join(_files_dir(), f"in_{msg.id}.txt")
            await msg.download_media(file=local)
            try:
                with open(local, encoding="utf-8") as f:
                    text = f.read()
            finally:
                try:
                    os.remove(local)
                except Exception:
                    pass
        if text:
            out.append(text)
        if msg.id > _last_seen_id[0]:
            _last_seen_id[0] = msg.id
    return json.dumps({"ok": True, "frames": out})


def poll(bot_id):
    try:
        return _run(_a_poll, bot_id, timeout=60)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


def logout():
    global _client
    try:
        if _client is not None:
            _run(_client.disconnect, timeout=20)
    except Exception:
        pass
    _client = None
    try:
        os.remove(_session_path())
    except Exception:
        pass
    return json.dumps({"ok": True})
