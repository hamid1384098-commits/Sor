package com.relaytunnel.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            AppLog.add("CRASH", "thread=${t.name}\n" + android.util.Log.getStackTraceString(e))
            old?.uncaughtException(t, e)
        }
    }
}
