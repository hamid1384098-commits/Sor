package com.relaytunnel.app

object NativeLauncher {
    init { System.loadLibrary("relaylauncher") }

    /** برمی‌گرداند [pid, readFd] (خروجی stdout/stderr فرزند) یا null. */
    @JvmStatic external fun spawn(path: String, args: Array<String>, keepFd: Int): IntArray?
    @JvmStatic external fun waitFor(pid: Int): Int
    @JvmStatic external fun kill(pid: Int)
}
