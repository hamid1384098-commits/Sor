package com.relaytunnel.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/**
 * پروتکل فریم‌های تانل (باید دقیقاً با worker.js یکی باشد):
 * یک پیام = {"v":1,"frames":[ {t, id, host?, port?, data?}, ... ]}
 *   t = "O" باز کردن اتصال جدید (host, port لازم است)
 *   t = "D" دادهٔ یک اتصال (data = base64 بایت‌ها)
 *   t = "C" بسته شدن اتصال
 *   t = "E" خطا در باز کردن / اجرای اتصال (data = متن خطا)
 */
sealed class Frame(val type: String, val id: Int) {
    class Open(id: Int, val host: String, val port: Int) : Frame("O", id)
    class Data(id: Int, val bytes: ByteArray) : Frame("D", id)
    class Close(id: Int) : Frame("C", id)
    class Err(id: Int, val message: String) : Frame("E", id)
}

object FrameProtocol {
    fun encode(frames: List<Frame>): String {
        val arr = JSONArray()
        for (f in frames) {
            val o = JSONObject()
            o.put("t", f.type)
            o.put("id", f.id)
            when (f) {
                is Frame.Open -> { o.put("host", f.host); o.put("port", f.port) }
                is Frame.Data -> o.put("data", Base64.encodeToString(f.bytes, Base64.NO_WRAP))
                is Frame.Close -> {}
                is Frame.Err -> o.put("data", f.message)
            }
            arr.put(o)
        }
        val root = JSONObject()
        root.put("v", 1)
        root.put("frames", arr)
        return root.toString()
    }

    fun decode(text: String): List<Frame> {
        val out = mutableListOf<Frame>()
        try {
            val root = JSONObject(text)
            val arr = root.optJSONArray("frames") ?: return out
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getInt("id")
                when (o.getString("t")) {
                    "O" -> out.add(Frame.Open(id, o.optString("host"), o.optInt("port")))
                    "D" -> out.add(Frame.Data(id, Base64.decode(o.optString("data"), Base64.NO_WRAP)))
                    "C" -> out.add(Frame.Close(id))
                    "E" -> out.add(Frame.Err(id, o.optString("data")))
                }
            }
        } catch (_: Exception) {
            // فریم خراب/ناقص را نادیده بگیر؛ تانل برای همین باید idempotent/قابل‌تحمل خطا باشد
        }
        return out
    }
}
