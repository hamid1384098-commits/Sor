package com.relaytunnel.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class AppSelectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_select)

        val pm = packageManager
        val all: List<ApplicationInfo> = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null } // فقط اپ‌هایی که آیکون/لانچر دارند
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val selected = Prefs.tunnelApps(this).toMutableSet()
        val lv = findViewById<ListView>(R.id.lvApps)
        lv.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        lv.adapter = AppListAdapter(pm, all, selected)

        findViewById<Button>(R.id.btnSaveApps).setOnClickListener {
            Prefs.setTunnelApps(this, selected)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
