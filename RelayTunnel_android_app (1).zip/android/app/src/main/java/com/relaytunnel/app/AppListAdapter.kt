package com.relaytunnel.app

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckedTextView

class AppListAdapter(
    private val pm: PackageManager,
    private val apps: List<ApplicationInfo>,
    private val checked: MutableSet<String>
) : BaseAdapter() {

    override fun getCount() = apps.size
    override fun getItem(position: Int) = apps[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView as? CheckedTextView
            ?: LayoutInflater.from(parent?.context).inflate(
                android.R.layout.simple_list_item_multiple_choice, parent, false
            ) as CheckedTextView
        val info = apps[position]
        view.text = pm.getApplicationLabel(info)
        view.isChecked = checked.contains(info.packageName)
        view.setOnClickListener {
            if (checked.contains(info.packageName)) checked.remove(info.packageName)
            else checked.add(info.packageName)
            view.isChecked = checked.contains(info.packageName)
        }
        return view
    }
}
