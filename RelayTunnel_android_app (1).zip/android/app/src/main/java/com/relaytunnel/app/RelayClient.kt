package com.relaytunnel.app

import android.util.Log
import java.io.OutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * مدیریت «استریم‌های» منطقی روی کانال بات. هر اتصال SOCKS5 یک streamId می‌گیرد.
 * فریم‌های خروجی batch می‌شوند (حداکثر هر ~120ms یک پیام) تا تعداد پیام‌ها/رفت‌وبرگشت‌ها
 * کم شود، چون هر پیام از مسیر حساب شخصی سروش رد می‌شود و تاخیر دارد.
 */
class RelayClient(private val botId: String) {
    companion object { private const val TAG = "RelayClient" }

    private val nextId = AtomicInteger(1)
    private val outQueue = LinkedBlockingQueue<Frame>()
    private val sinks = ConcurrentHashMap<Int, OutputStream>()
    private val running = AtomicBoolean(false)
    @Volatile private var lastPollErr = ""

    fun start() {
        if (!running.compareAndSet(false, true)) return
        AppLog.add("RELAY", "شروع؛ botId=$botId")
        Thread({
            while (running.get()) {
                try { PyBridge.drainLogs().forEach { AppLog.add("PYLOG", it) } } catch (_: Throwable) {}
                try { Thread.sleep(700) } catch (_: InterruptedException) { break }
            }
        }, "relay-pylog").start()
        Thread(this::senderLoop, "relay-sender").start()
        Thread(this::pollerLoop, "relay-poller").start()
    }

    fun stop() {
        running.set(false)
    }

    fun newStreamId(): Int = nextId.getAndIncrement()

    fun registerSink(streamId: Int, sink: OutputStream) {
        sinks[streamId] = sink
    }

    fun unregisterSink(streamId: Int) {
        sinks.remove(streamId)
    }

    fun open(streamId: Int, host: String, port: Int) {
        outQueue.put(Frame.Open(streamId, host, port))
    }

    fun sendData(streamId: Int, bytes: ByteArray) {
        outQueue.put(Frame.Data(streamId, bytes))
    }

    fun close(streamId: Int) {
        outQueue.put(Frame.Close(streamId))
    }

    private fun senderLoop() {
        while (running.get()) {
            try {
                val first = outQueue.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                val batch = mutableListOf(first)
                // کمی صبر کن تا فریم‌های نزدیک به هم با هم بروند (کاهش تعداد پیام)
                Thread.sleep(80)
                outQueue.drainTo(batch, 200)
                val text = FrameProtocol.encode(batch)
                AppLog.add("SEND", "شروع ارسال: ${batch.size} فریم، طول=${text.length}")
                val t0 = System.currentTimeMillis()
                val res = PyBridge.sendFrame(botId, text)
                val dt = System.currentTimeMillis() - t0
                if (!res.optBoolean("ok")) {
                    Log.w(TAG, "send error: " + res.optString("error"))
                    AppLog.e("SEND", res.optString("error"))
                } else {
                    AppLog.add("SEND", "ارسال شد: ${batch.size} فریم (${batch.joinToString("") { it.type }}) طول=${text.length} زمان=${dt}ms")
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                Log.w(TAG, "sender loop error", e); AppLog.e("SEND", "استثنا در حلقه‌ی ارسال", e)
            }
        }
    }

    private fun pollerLoop() {
        while (running.get()) {
            try {
                val t0 = System.currentTimeMillis()
                val res = PyBridge.poll(botId)
                val dt = System.currentTimeMillis() - t0
                if (dt > 3000) AppLog.add("POLL", "poll کند بود: ${dt}ms")
                if (!res.optBoolean("ok")) {
                    val err = res.optString("error")
                    if (err != lastPollErr) { lastPollErr = err; AppLog.e("POLL", err) }
                }
                if (res.optBoolean("ok")) {
                    lastPollErr = ""
                    val arr = res.optJSONArray("frames")
                    if (arr != null && arr.length() > 0) AppLog.add("POLL", "دریافت: ${arr.length()} پیام")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            dispatchIncoming(arr.getString(i))
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "poll loop error", e); AppLog.e("POLL", "استثنا در حلقه‌ی دریافت", e)
            }
            try { Thread.sleep(1200) } catch (_: InterruptedException) { break }
        }
    }

    private fun dispatchIncoming(text: String) {
        for (f in FrameProtocol.decode(text)) {
            when (f) {
                is Frame.Data -> {
                    val sink = sinks[f.id] ?: continue
                    try { sink.write(f.bytes); sink.flush() } catch (_: Exception) { sinks.remove(f.id) }
                }
                is Frame.Close, is Frame.Err -> {
                    sinks.remove(f.id)?.let { try { it.close() } catch (_: Exception) {} }
                }
                else -> {}
            }
        }
    }
}
