package com.relaytunnel.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** لاگ ساده‌ی داخل اپ: در حافظه + فایل relay.log (تا بعد از کرش هم قابل دیدن باشد). */
object AppLog {
    private const val MAX_LINES = 600
    private const val MAX_FILE = 200_000L
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun init(ctx: Context) {
        if (file != null) return
        file = File(ctx.filesDir, "relay.log")
        try {
            val f = file!!
            if (f.exists() && f.length() > MAX_FILE) f.delete()
            if (f.exists()) f.readLines().takeLast(200).forEach { lines.addLast(it) }
        } catch (_: Exception) {}
        add("APP", "---- شروع اپ ----")
    }

    @Synchronized
    fun add(tag: String, msg: String) {
        val line = "${fmt.format(Date())} [$tag] $msg"
        Log.d("RelayLog", line)
        lines.addLast(line)
        while (lines.size > MAX_LINES) lines.removeFirst()
        try { file?.appendText(line + "\n") } catch (_: Exception) {}
    }

    fun e(tag: String, msg: String, t: Throwable? = null) =
        add(tag, "ERROR: $msg" + (t?.let { " | " + it.toString() } ?: ""))

    @Synchronized
    fun text(): String = lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
        try { file?.writeText("") } catch (_: Exception) {}
    }
}
