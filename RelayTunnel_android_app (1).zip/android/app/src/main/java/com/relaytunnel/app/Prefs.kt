package com.relaytunnel.app

import android.content.Context

object Prefs {
    private const val NAME = "relay_prefs"
    private const val KEY_BOT_ID = "bot_id"
    private const val KEY_BOT_NAME = "bot_name"
    private const val KEY_APPS = "tunnel_apps"

    private fun sp(ctx: Context) = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun setBot(ctx: Context, id: String, name: String) {
        sp(ctx).edit().putString(KEY_BOT_ID, id).putString(KEY_BOT_NAME, name).apply()
    }

    fun botId(ctx: Context): String? = sp(ctx).getString(KEY_BOT_ID, null)
    fun botName(ctx: Context): String? = sp(ctx).getString(KEY_BOT_NAME, null)

    fun setTunnelApps(ctx: Context, packages: Set<String>) {
        sp(ctx).edit().putStringSet(KEY_APPS, packages).apply()
    }

    fun tunnelApps(ctx: Context): Set<String> =
        sp(ctx).getStringSet(KEY_APPS, emptySet()) ?: emptySet()
}
