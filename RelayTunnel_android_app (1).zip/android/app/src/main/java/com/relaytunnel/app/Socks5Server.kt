package com.relaytunnel.app

import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/**
 * سرور SOCKS5 محلی و حداقلی: فقط دستور CONNECT (0x01) را پشتیبانی می‌کند و بدون
 * authentication کار می‌کند (فقط روی 127.0.0.1 گوش می‌دهد و tun2socks به آن وصل می‌شود).
 * هر اتصال پذیرفته‌شده یک streamId از RelayClient می‌گیرد و داده‌اش از طریق بات رد می‌شود.
 */
class Socks5Server(private val port: Int, private val relay: RelayClient) : Thread("socks5-server") {
    companion object { private const val TAG = "Socks5Server" }
    private val running = AtomicBoolean(true)
    private var server: ServerSocket? = null

    fun shutdown() {
        running.set(false)
        try { server?.close() } catch (_: Exception) {}
    }

    override fun run() {
        try {
            server = ServerSocket()
            server!!.reuseAddress = true
            server!!.bind(InetSocketAddress("127.0.0.1", port))
        } catch (e: Exception) {
            Log.e(TAG, "cannot bind socks5 port $port", e)
            AppLog.e("SOCKS", "bind روی پورت $port شکست خورد", e)
            return
        }
        AppLog.add("SOCKS", "سرور SOCKS5 روی 127.0.0.1:$port آماده است")
        while (running.get()) {
            val client = try { server!!.accept() } catch (e: Exception) { break }
            Thread { handle(client) }.start()
        }
    }

    private fun handle(client: Socket) {
        var streamId = -1
        try {
            val din = DataInputStream(client.getInputStream())
            val dout = client.getOutputStream()

            // --- greeting: VER NMETHODS METHODS...
            val ver = din.readUnsignedByte()
            if (ver != 5) { client.close(); return }
            val nMethods = din.readUnsignedByte()
            val methods = ByteArray(nMethods)
            din.readFully(methods)
            dout.write(byteArrayOf(5, 0)) // no-auth
            dout.flush()

            // --- request: VER CMD RSV ATYP DST.ADDR DST.PORT
            val rver = din.readUnsignedByte()
            val cmd = din.readUnsignedByte()
            din.readUnsignedByte() // RSV
            val atyp = din.readUnsignedByte()
            val host: String = when (atyp) {
                1 -> { // IPv4
                    val b = ByteArray(4); din.readFully(b)
                    (b[0].toInt() and 0xFF).toString() + "." + (b[1].toInt() and 0xFF) + "." +
                        (b[2].toInt() and 0xFF) + "." + (b[3].toInt() and 0xFF)
                }
                3 -> { // domain
                    val len = din.readUnsignedByte()
                    val b = ByteArray(len); din.readFully(b)
                    String(b, Charsets.US_ASCII)
                }
                4 -> { // IPv6 - خیلی کم پیش می‌آید؛ همین قدر بخوان که جریان خراب نشود
                    val b = ByteArray(16); din.readFully(b)
                    java.net.InetAddress.getByAddress(b).hostAddress ?: "::1"
                }
                else -> { client.close(); return }
            }
            val portHi = din.readUnsignedByte(); val portLo = din.readUnsignedByte()
            val destPort = (portHi shl 8) or portLo

            if (rver == 5 && cmd == 3) {   // UDP ASSOCIATE (برای DNS)
                handleUdp(client, dout)
                return
            }
            if (rver != 5 || cmd != 1) {
                // فقط CONNECT پشتیبانی می‌شود
                dout.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0))
                client.close()
                return
            }

            streamId = relay.newStreamId()
            AppLog.add("SOCKS", "اتصال جدید #$streamId -> $host:$destPort")
            relay.registerSink(streamId, dout)
            relay.open(streamId, host, destPort)

            // پاسخ موفق را فوری می‌فرستیم (واقعی‌شدن اتصال از راه دور ممکن است چند صدم ثانیه طول بکشد؛
            // برنامه‌ها معمولاً تحمل تاخیر اول اتصال را دارند)
            dout.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            dout.flush()

            // هر چه از اپ محلی می‌آید را به صورت فریم DATA بفرست
            val buf = ByteArray(16 * 1024)
            val input = client.getInputStream()
            while (running.get()) {
                val n = input.read(buf)
                if (n < 0) break
                relay.sendData(streamId, buf.copyOf(n))
            }
        } catch (_: Exception) {
            // قطع عادی اتصال
        } finally {
            if (streamId >= 0) {
                relay.unregisterSink(streamId)
                relay.close(streamId)
            }
            try { client.close() } catch (_: Exception) {}
        }
    }

    // ---------------------------------------------------------------
    // UDP ASSOCIATE: فقط DNS (پورت 53) پشتیبانی می‌شود؛ هر پرسش به DNS-over-TCP
    // روی تانل تبدیل می‌شود. بقیه‌ی UDP دور ریخته می‌شود.
    // ---------------------------------------------------------------
    private val dnsCache = ConcurrentHashMap<String, Pair<Long, ByteArray>>()

    private fun handleUdp(client: Socket, dout: OutputStream) {
        val ds = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        try {
            val bp = ds.localPort
            dout.write(byteArrayOf(5, 0, 0, 1, 127, 0, 0, 1, (bp shr 8).toByte(), (bp and 0xFF).toByte()))
            dout.flush()
            AppLog.add("SOCKS", "UDP associate روی پورت $bp")
            Thread {
                val buf = ByteArray(4096)
                while (running.get() && !ds.isClosed) {
                    val p = DatagramPacket(buf, buf.size)
                    try { ds.receive(p) } catch (_: Exception) { break }
                    val data = p.data.copyOfRange(p.offset, p.offset + p.length)
                    val addr = p.address; val port = p.port
                    Thread { handleUdpPacket(ds, addr, port, data) }.start()
                }
            }.start()
            // تا وقتی اتصال کنترلی TCP باز است، association زنده می‌ماند
            try { while (client.getInputStream().read() >= 0) { } } catch (_: Exception) {}
        } finally {
            ds.close()
        }
    }

    private fun qname(dns: ByteArray): String {
        val sb = StringBuilder()
        var i = 12
        while (i < dns.size) {
            val l = dns[i].toInt() and 0xFF
            if (l == 0 || i + 1 + l > dns.size) break
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i + 1, l, Charsets.US_ASCII))
            i += l + 1
        }
        return sb.toString()
    }

    private fun handleUdpPacket(ds: DatagramSocket, srcAddr: InetAddress, srcPort: Int, d: ByteArray) {
        try {
            if (d.size < 10) return
            val atyp = d[3].toInt() and 0xFF
            var off = 4
            val host: String
            when (atyp) {
                1 -> { host = (0..3).joinToString(".") { (d[4 + it].toInt() and 0xFF).toString() }; off += 4 }
                3 -> { val l = d[4].toInt() and 0xFF; host = String(d, 5, l, Charsets.US_ASCII); off += 1 + l }
                4 -> { host = InetAddress.getByAddress(d.copyOfRange(4, 20)).hostAddress ?: return; off += 16 }
                else -> return
            }
            val port = ((d[off].toInt() and 0xFF) shl 8) or (d[off + 1].toInt() and 0xFF)
            off += 2
            val header = d.copyOfRange(0, off)
            val query = d.copyOfRange(off, d.size)
            if (port != 53 || query.size < 12) {
                AppLog.add("DNS", "UDP غیر DNS دور ریخته شد (-> $host:$port)")
                return
            }
            val name = qname(query)
            val key = String(query, 2, query.size - 2, Charsets.ISO_8859_1)
            val hit = dnsCache[key]
            var answer: ByteArray? = null
            if (hit != null && System.currentTimeMillis() - hit.first < 120_000) {
                answer = hit.second.copyOf()
                answer[0] = query[0]; answer[1] = query[1]
                AppLog.add("DNS", "$name (کش)")
            } else {
                answer = dnsOverTunnel(host, query)
                if (answer != null) {
                    dnsCache[key] = Pair(System.currentTimeMillis(), answer)
                    AppLog.add("DNS", "$name ← جواب ${answer.size} بایت")
                } else {
                    AppLog.add("DNS", "$name ← timeout")
                }
            }
            if (answer == null) return
            val out = header + answer
            ds.send(DatagramPacket(out, out.size, srcAddr, srcPort))
        } catch (e: Exception) {
            AppLog.e("DNS", "خطا", e)
        }
    }

    private fun dnsOverTunnel(host: String, query: ByteArray): ByteArray? {
        val id = relay.newStreamId()
        val latch = CountDownLatch(1)
        val resp = ByteArrayOutputStream()
        val sink = object : OutputStream() {
            override fun write(b: Int) { write(byteArrayOf(b.toByte()), 0, 1) }
            override fun write(b: ByteArray, off: Int, len: Int) {
                synchronized(resp) {
                    resp.write(b, off, len)
                    val a = resp.toByteArray()
                    if (a.size >= 2) {
                        val l = ((a[0].toInt() and 0xFF) shl 8) or (a[1].toInt() and 0xFF)
                        if (a.size >= l + 2) latch.countDown()
                    }
                }
            }
        }
        relay.registerSink(id, sink)
        relay.open(id, host, 53)
        val framed = ByteArray(2 + query.size)
        framed[0] = (query.size shr 8).toByte(); framed[1] = (query.size and 0xFF).toByte()
        System.arraycopy(query, 0, framed, 2, query.size)
        relay.sendData(id, framed)
        val ok = latch.await(20, TimeUnit.SECONDS)
        relay.unregisterSink(id)
        relay.close(id)
        if (!ok) return null
        val a = synchronized(resp) { resp.toByteArray() }
        val l = ((a[0].toInt() and 0xFF) shl 8) or (a[1].toInt() and 0xFF)
        return a.copyOfRange(2, 2 + l)
    }
}
