package com.relaytunnel.app

import android.util.Log
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

/**
 * سرور SOCKS5 محلی و حداقلی: فقط دستور CONNECT (0x01) را پشتیبانی می‌کند و بدون
 * authentication کار می‌کند (فقط روی 127.0.0.1 گوش می‌دهد و tun2socks به آن وصل می‌شود).
 * هر اتصال پذیرفته‌شده یک streamId از RelayClient می‌گیرد و داده‌اش از طریق بات رد می‌شود.
 */
class Socks5Server(private val port: Int, private val relay: RelayClient) : Thread("socks5-server") {
    companion object { private const val TAG = "Socks5Server" }
    private val running = AtomicBoolean(true)
    private var server: ServerSocket? = null

    fun shutdown() {
        running.set(false)
        try { server?.close() } catch (_: Exception) {}
    }

    override fun run() {
        try {
            server = ServerSocket()
            server!!.reuseAddress = true
            server!!.bind(InetSocketAddress("127.0.0.1", port))
        } catch (e: Exception) {
            Log.e(TAG, "cannot bind socks5 port $port", e)
            AppLog.e("SOCKS", "bind روی پورت $port شکست خورد", e)
            return
        }
        AppLog.add("SOCKS", "سرور SOCKS5 روی 127.0.0.1:$port آماده است")
        while (running.get()) {
            val client = try { server!!.accept() } catch (e: Exception) { break }
            Thread { handle(client) }.start()
        }
    }

    private fun handle(client: Socket) {
        var streamId = -1
        try {
            val din = DataInputStream(client.getInputStream())
            val dout = client.getOutputStream()

            // --- greeting: VER NMETHODS METHODS...
            val ver = din.readUnsignedByte()
            if (ver != 5) { client.close(); return }
            val nMethods = din.readUnsignedByte()
            val methods = ByteArray(nMethods)
            din.readFully(methods)
            dout.write(byteArrayOf(5, 0)) // no-auth
            dout.flush()

            // --- request: VER CMD RSV ATYP DST.ADDR DST.PORT
            val rver = din.readUnsignedByte()
            val cmd = din.readUnsignedByte()
            din.readUnsignedByte() // RSV
            val atyp = din.readUnsignedByte()
            val host: String = when (atyp) {
                1 -> { // IPv4
                    val b = ByteArray(4); din.readFully(b)
                    (b[0].toInt() and 0xFF).toString() + "." + (b[1].toInt() and 0xFF) + "." +
                        (b[2].toInt() and 0xFF) + "." + (b[3].toInt() and 0xFF)
                }
                3 -> { // domain
                    val len = din.readUnsignedByte()
                    val b = ByteArray(len); din.readFully(b)
                    String(b, Charsets.US_ASCII)
                }
                4 -> { // IPv6 - خیلی کم پیش می‌آید؛ همین قدر بخوان که جریان خراب نشود
                    val b = ByteArray(16); din.readFully(b)
                    java.net.InetAddress.getByAddress(b).hostAddress ?: "::1"
                }
                else -> { client.close(); return }
            }
            val portHi = din.readUnsignedByte(); val portLo = din.readUnsignedByte()
            val destPort = (portHi shl 8) or portLo

            if (rver != 5 || cmd != 1) {
                // فقط CONNECT پشتیبانی می‌شود
                dout.write(byteArrayOf(5, 7, 0, 1, 0, 0, 0, 0, 0, 0))
                client.close()
                return
            }

            streamId = relay.newStreamId()
            AppLog.add("SOCKS", "اتصال جدید #$streamId -> $host:$destPort")
            relay.registerSink(streamId, dout)
            relay.open(streamId, host, destPort)

            // پاسخ موفق را فوری می‌فرستیم (واقعی‌شدن اتصال از راه دور ممکن است چند صدم ثانیه طول بکشد؛
            // برنامه‌ها معمولاً تحمل تاخیر اول اتصال را دارند)
            dout.write(byteArrayOf(5, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            dout.flush()

            // هر چه از اپ محلی می‌آید را به صورت فریم DATA بفرست
            val buf = ByteArray(16 * 1024)
            val input = client.getInputStream()
            while (running.get()) {
                val n = input.read(buf)
                if (n < 0) break
                relay.sendData(streamId, buf.copyOf(n))
            }
        } catch (_: Exception) {
            // قطع عادی اتصال
        } finally {
            if (streamId >= 0) {
                relay.unregisterSink(streamId)
                relay.close(streamId)
            }
            try { client.close() } catch (_: Exception) {}
        }
    }
}
