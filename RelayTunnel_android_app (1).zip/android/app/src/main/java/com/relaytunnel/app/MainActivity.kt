package com.relaytunnel.app

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val vpnPrepareCode = 100
    private lateinit var swTunnel: Switch
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.tvBot).text = "بات انتخابی: " + (Prefs.botName(this) ?: "-")
        findViewById<TextView>(R.id.tvAppsCount).text =
            "تعداد اپ‌های تانل‌شده: ${Prefs.tunnelApps(this).size}"

        findViewById<Button>(R.id.btnChangeBot).setOnClickListener {
            startActivity(Intent(this, BotSelectActivity::class.java))
        }
        findViewById<Button>(R.id.btnChangeApps).setOnClickListener {
            startActivity(Intent(this, AppSelectActivity::class.java))
        }

        findViewById<Button>(R.id.btnLog).setOnClickListener {
            startActivity(Intent(this, LogActivity::class.java))
        }

        findViewById<Button>(R.id.btnTestSend).setOnClickListener {
            val bid = Prefs.botId(this)
            if (bid == null) { AppLog.add("TEST", "اول بات را انتخاب کن"); return@setOnClickListener }
            AppLog.add("TEST", "تست ارسال شروع شد (ارسال فایل txt؛ حدود ۱ دقیقه)...")
            Thread {
                try {
                    PyBridge.init(applicationContext)
                    val r = PyBridge.testSend(bid)
                    AppLog.add("TEST", "نتیجه: $r")
                } catch (e: Throwable) { AppLog.e("TEST", "خطا", e) }
            }.start()
            startActivity(Intent(this, LogActivity::class.java))
        }

        swTunnel = findViewById(R.id.swTunnel)
        tvStatus = findViewById(R.id.tvStatus)
        swTunnel.isChecked = TunnelVpnService.isRunning
        tvStatus.text = if (TunnelVpnService.isRunning) "فعال" else "غیرفعال"

        swTunnel.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) startTunnel() else stopTunnel()
        }
    }

    private fun startTunnel() {
        if (Prefs.botId(this) == null) {
            tvStatus.text = "اول یک بات انتخاب کن"
            swTunnel.isChecked = false
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, vpnPrepareCode)
        } else {
            onActivityResult(vpnPrepareCode, RESULT_OK, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnPrepareCode) {
            if (resultCode == RESULT_OK) {
                val svc = Intent(this, TunnelVpnService::class.java)
                svc.action = TunnelVpnService.ACTION_START
                startService(svc)
                tvStatus.text = "فعال"
            } else {
                swTunnel.isChecked = false
                tvStatus.text = "اجازه VPN داده نشد"
            }
        }
    }

    private fun stopTunnel() {
        val svc = Intent(this, TunnelVpnService::class.java)
        svc.action = TunnelVpnService.ACTION_STOP
        startService(svc)
        tvStatus.text = "غیرفعال"
    }
}
