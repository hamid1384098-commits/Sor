package com.relaytunnel.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LogActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tv: TextView
    private lateinit var sv: ScrollView
    private var lastLen = -1

    private val tick = object : Runnable {
        override fun run() {
            val t = AppLog.text()
            if (t.length != lastLen) {
                lastLen = t.length
                tv.text = t
                sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)
        tv = findViewById(R.id.tvLog)
        sv = findViewById(R.id.svLog)
        findViewById<Button>(R.id.btnCopyLog).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", AppLog.text()))
            Toast.makeText(this, "کپی شد", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            AppLog.clear(); lastLen = -1
        }
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick) }
}
