// اجرای tun2socks به‌عنوان پردازه‌ی فرزند «با حفظ fd رابط tun».
// ProcessBuilder اندروید همه‌ی fdهای >2 را در فرزند می‌بندد؛ اینجا خودمان fork/exec می‌کنیم.
#include <jni.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

JNIEXPORT jintArray JNICALL
Java_com_relaytunnel_app_NativeLauncher_spawn(JNIEnv *env, jclass cls, jstring jpath,
                                              jobjectArray jargs, jint keepFd) {
    const char *cpath = (*env)->GetStringUTFChars(env, jpath, NULL);
    char *path = strdup(cpath);
    (*env)->ReleaseStringUTFChars(env, jpath, cpath);

    int n = (*env)->GetArrayLength(env, jargs);
    char **argv = (char **)calloc((size_t)n + 1, sizeof(char *));
    for (int i = 0; i < n; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, jargs, i);
        const char *c = (*env)->GetStringUTFChars(env, s, NULL);
        argv[i] = strdup(c);
        (*env)->ReleaseStringUTFChars(env, s, c);
        (*env)->DeleteLocalRef(env, s);
    }
    argv[n] = NULL;

    int pfd[2];
    if (pipe(pfd) != 0) return NULL;

    pid_t pid = fork();
    if (pid == 0) {
        // --- پردازه‌ی فرزند: فقط توابع async-signal-safe
        dup2(pfd[1], 1);
        dup2(pfd[1], 2);
        int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) dup2(nul, 0);
        for (int fd = 3; fd < 1024; fd++) {
            if (fd != keepFd) close(fd);
        }
        fcntl(keepFd, F_SETFD, 0);  // CLOEXEC خاموش => بعد از exec هم باز می‌ماند
        execv(path, argv);
        _exit(127);
    }

    close(pfd[1]);
    for (int i = 0; i < n; i++) free(argv[i]);
    free(argv);
    free(path);
    if (pid < 0) { close(pfd[0]); return NULL; }

    jintArray res = (*env)->NewIntArray(env, 2);
    jint v[2] = { (jint)pid, (jint)pfd[0] };
    (*env)->SetIntArrayRegion(env, res, 0, 2, v);
    return res;
}

JNIEXPORT jint JNICALL
Java_com_relaytunnel_app_NativeLauncher_waitFor(JNIEnv *env, jclass cls, jint pid) {
    int st = 0;
    pid_t r;
    do { r = waitpid((pid_t)pid, &st, 0); } while (r < 0 && errno == EINTR);
    if (r < 0) return -1;
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return -2;
}

JNIEXPORT void JNICALL
Java_com_relaytunnel_app_NativeLauncher_kill(JNIEnv *env, jclass cls, jint pid) {
    if (pid > 0) kill((pid_t)pid, SIGTERM);
}
