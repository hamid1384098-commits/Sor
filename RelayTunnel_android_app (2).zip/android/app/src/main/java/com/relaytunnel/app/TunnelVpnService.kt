package com.relaytunnel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import android.util.Log

class TunnelVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.relaytunnel.app.START"
        const val ACTION_STOP = "com.relaytunnel.app.STOP"
        private const val CHANNEL_ID = "relay_tunnel"
        private const val NOTIF_ID = 1
        private const val SOCKS_PORT = 38080
        private const val TAG = "TunnelVpnService"

        @Volatile var isRunning = false
            private set
    }

    private var tunFd: ParcelFileDescriptor? = null
    private var socks: Socks5Server? = null
    private var relay: RelayClient? = null
    private var t2sPid: Int = -1

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopTunnel(); stopSelf() }
            else -> try { startTunnel() } catch (e: Throwable) {
                Log.e(TAG, "startTunnel failed", e); AppLog.e("VPN", "startTunnel", e); stopTunnel(); stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startTunnel() {
        if (isRunning) return
        val botId = Prefs.botId(this) ?: run {
            Log.e(TAG, "no bot selected"); stopSelf(); return
        }
        AppLog.add("VPN", "شروع تانل؛ botId=$botId")
        PyBridge.init(applicationContext)
        AppLog.add("VPN", "کتابخانه‌ی سروش: " + PyBridge.diag())
        startForeground(NOTIF_ID, buildNotification())

        val builder = Builder()
            .setSession("RelayTunnel")
            .setMtu(1500)
            .addAddress("10.10.0.2", 24)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)

        val apps = Prefs.tunnelApps(this)
        if (apps.isEmpty()) {
            Log.w(TAG, "هیچ اپی انتخاب نشده؛ هیچ ترافیکی از تانل رد نمی‌شود")
        } else {
            for (pkg in apps) {
                try { builder.addAllowedApplication(pkg) } catch (e: Exception) {
                    Log.w(TAG, "app not found: $pkg")
                }
            }
        }

        AppLog.add("VPN", "اپ‌های انتخابی: ${apps.size}")
        bindToUnderlying()
        tunFd = builder.establish()
        AppLog.add("VPN", if (tunFd == null) "establish ناموفق" else "رابط tun ساخته شد fd=${tunFd!!.fd}")
        if (tunFd == null) {
            Log.e(TAG, "establish() failed"); stopSelf(); return
        }

        relay = RelayClient(botId).also { it.start() }
        socks = Socks5Server(SOCKS_PORT, relay!!).also { it.start() }

        launchTun2socks(tunFd!!, SOCKS_PORT)
        isRunning = true
        AppLog.add("VPN", "تانل فعال شد")
    }

    /**
     * باینری libtun2socks.so (کپی‌شده در jniLibs با نام .so تا روی اندروید ۱۰+ قابل اجرا باشد)
     * را با fd خامِ tun اجرا می‌کند. چون fork روی لینوکس/اندروید فایل‌دسکریپتورهای باز را به
     * فرزند منتقل می‌کند (مگر CLOEXEC ست شده باشد)، اول CLOEXEC این fd را پاک می‌کنیم.
     *
     * ⚠️ نام فلگ‌های خط‌فرمان (-device/-proxy/-loglevel) بسته به نسخه‌ی tun2socks ممکن است
     * فرق کند؛ اگر سرویس بالا نیامد، با adb logcat خروجی پردازه را ببین و طبق خروجی
     * `tun2socks -h` همین‌جا اصلاح کن.
     */
    private fun launchTun2socks(pfd: ParcelFileDescriptor, socksPort: Int) {
        try {
            val fdNum = pfd.fd
            val bin = applicationInfo.nativeLibraryDir + "/libtun2socks.so"
            val args = arrayOf(
                bin,
                "-device", "fd://$fdNum",
                "-proxy", "socks5://127.0.0.1:$socksPort",
                "-mtu", "1500",
                "-loglevel", "warning"
            )
            AppLog.add("T2S", "اجرا: " + args.joinToString(" "))
            val res = NativeLauncher.spawn(bin, args, fdNum)
                ?: throw RuntimeException("fork/exec شکست خورد")
            val pid = res[0]
            t2sPid = pid
            val rpfd = ParcelFileDescriptor.adoptFd(res[1])
            AppLog.add("T2S", "پردازه شروع شد pid=$pid")
            Thread {
                try {
                    java.io.FileInputStream(rpfd.fileDescriptor).bufferedReader()
                        .forEachLine { AppLog.add("T2S", it) }
                } catch (_: Exception) {}
                try { rpfd.close() } catch (_: Exception) {}
            }.start()
            Thread {
                val code = NativeLauncher.waitFor(pid)
                AppLog.add("T2S", "پردازه tun2socks تمام شد؛ exit=$code")
            }.start()
        } catch (e: Throwable) {
            Log.e(TAG, "launchTun2socks failed", e)
            AppLog.e("T2S", "اجرای tun2socks شکست خورد", e)
        }
    }

    /** ترافیک خود اپ (اتصال‌های جدید به سروش/آپلود) را صراحتاً روی شبکه‌ی غیر-VPN ببند. */
    private fun bindToUnderlying() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var chosen: Network? = null
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                if (!c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
                if (chosen == null || c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) chosen = n
            }
            if (chosen == null) {
                AppLog.add("VPN", "شبکه‌ی غیر-VPN برای bind پیدا نشد")
            } else {
                val ok = cm.bindProcessToNetwork(chosen)
                AppLog.add("VPN", "bindProcessToNetwork => $ok ($chosen)")
            }
        } catch (e: Throwable) {
            AppLog.e("VPN", "bindProcessToNetwork", e)
        }
    }

    private fun unbindUnderlying() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.bindProcessToNetwork(null)
        } catch (_: Throwable) {}
    }

    private fun stopTunnel() {
        AppLog.add("VPN", "توقف تانل")
        isRunning = false
        try { if (t2sPid > 0) NativeLauncher.kill(t2sPid) } catch (_: Throwable) {}
        t2sPid = -1
        socks?.shutdown(); socks = null
        relay?.stop(); relay = null
        try { tunFd?.close() } catch (_: Exception) {}
        tunFd = null
        unbindUnderlying()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "تانل فیلترشکن", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("تانل فعال است")
            .setContentText("ترافیک اپ‌های انتخابی از طریق بات رد می‌شود")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }
}
