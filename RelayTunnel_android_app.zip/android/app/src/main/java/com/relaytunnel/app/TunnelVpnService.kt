package com.relaytunnel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import android.util.Log

class TunnelVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.relaytunnel.app.START"
        const val ACTION_STOP = "com.relaytunnel.app.STOP"
        private const val CHANNEL_ID = "relay_tunnel"
        private const val NOTIF_ID = 1
        private const val SOCKS_PORT = 38080
        private const val TAG = "TunnelVpnService"

        @Volatile var isRunning = false
            private set
    }

    private var tunFd: ParcelFileDescriptor? = null
    private var socks: Socks5Server? = null
    private var relay: RelayClient? = null
    private var tun2socksProcess: Process? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopTunnel(); stopSelf() }
            else -> try { startTunnel() } catch (e: Throwable) {
                Log.e(TAG, "startTunnel failed", e); stopTunnel(); stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startTunnel() {
        if (isRunning) return
        val botId = Prefs.botId(this) ?: run {
            Log.e(TAG, "no bot selected"); stopSelf(); return
        }
        PyBridge.init(applicationContext)
        startForeground(NOTIF_ID, buildNotification())

        val builder = Builder()
            .setSession("RelayTunnel")
            .setMtu(1500)
            .addAddress("10.10.0.2", 24)
            .addDnsServer("1.1.1.1")
            .addRoute("0.0.0.0", 0)

        val apps = Prefs.tunnelApps(this)
        if (apps.isEmpty()) {
            Log.w(TAG, "هیچ اپی انتخاب نشده؛ هیچ ترافیکی از تانل رد نمی‌شود")
        } else {
            for (pkg in apps) {
                try { builder.addAllowedApplication(pkg) } catch (e: Exception) {
                    Log.w(TAG, "app not found: $pkg")
                }
            }
        }

        tunFd = builder.establish()
        if (tunFd == null) {
            Log.e(TAG, "establish() failed"); stopSelf(); return
        }

        relay = RelayClient(botId).also { it.start() }
        socks = Socks5Server(SOCKS_PORT, relay!!).also { it.start() }

        launchTun2socks(tunFd!!, SOCKS_PORT)
        isRunning = true
    }

    /**
     * باینری libtun2socks.so (کپی‌شده در jniLibs با نام .so تا روی اندروید ۱۰+ قابل اجرا باشد)
     * را با fd خامِ tun اجرا می‌کند. چون fork روی لینوکس/اندروید فایل‌دسکریپتورهای باز را به
     * فرزند منتقل می‌کند (مگر CLOEXEC ست شده باشد)، اول CLOEXEC این fd را پاک می‌کنیم.
     *
     * ⚠️ نام فلگ‌های خط‌فرمان (-device/-proxy/-loglevel) بسته به نسخه‌ی tun2socks ممکن است
     * فرق کند؛ اگر سرویس بالا نیامد، با adb logcat خروجی پردازه را ببین و طبق خروجی
     * `tun2socks -h` همین‌جا اصلاح کن.
     */
    private fun launchTun2socks(pfd: ParcelFileDescriptor, socksPort: Int) {
        try {
            Os.fcntlInt(pfd.fileDescriptor, OsConstants.F_SETFD, 0) // پاک کردن CLOEXEC
            val fdNum = pfd.fd
            val bin = applicationInfo.nativeLibraryDir + "/libtun2socks.so"
            val cmd = listOf(
                bin,
                "-device", "fd://$fdNum",
                "-proxy", "socks5://127.0.0.1:$socksPort",
                "-loglevel", "warning"
            )
            val pb = ProcessBuilder(cmd)
            pb.redirectErrorStream(true)
            tun2socksProcess = pb.start()
            Thread {
                try {
                    tun2socksProcess?.inputStream?.bufferedReader()?.forEachLine { Log.d("tun2socks", it) }
                } catch (_: Exception) {}
            }.start()
        } catch (e: Exception) {
            Log.e(TAG, "launchTun2socks failed", e)
        }
    }

    private fun stopTunnel() {
        isRunning = false
        try { tun2socksProcess?.destroy() } catch (_: Exception) {}
        tun2socksProcess = null
        socks?.shutdown(); socks = null
        relay?.stop(); relay = null
        try { tunFd?.close() } catch (_: Exception) {}
        tunFd = null
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "تانل فیلترشکن", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("تانل فعال است")
            .setContentText("ترافیک اپ‌های انتخابی از طریق بات رد می‌شود")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }
}
