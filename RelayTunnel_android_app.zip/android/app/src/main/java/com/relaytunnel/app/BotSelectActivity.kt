package com.relaytunnel.app

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

class BotSelectActivity : AppCompatActivity() {
    private lateinit var lv: ListView
    private val scope = CoroutineScope(Dispatchers.Main)
    private var ids = listOf<String>()
    private var names = listOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bot_select)
        lv = findViewById(R.id.lvBots)
        findViewById<Button>(R.id.btnRefresh).setOnClickListener { load() }

        lv.setOnItemClickListener { _, _, pos, _ ->
            Prefs.setBot(this, ids[pos], names[pos])
            startActivity(Intent(this, AppSelectActivity::class.java))
            finish()
        }
        load()
    }

    private fun load() {
        scope.launch {
            val res = try { withContext(Dispatchers.IO) { PyBridge.init(applicationContext); PyBridge.listBots() } }
                catch (e: Throwable) { org.json.JSONObject().put("ok", false).put("error", e.toString()) }
            if (!res.optBoolean("ok")) {
                Toast.makeText(this@BotSelectActivity, "خطا: " + res.optString("error"), Toast.LENGTH_LONG).show()
                return@launch
            }
            val arr: JSONArray = res.getJSONArray("bots")
            val idList = mutableListOf<String>()
            val nameList = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                idList.add(o.getString("id"))
                val uname = o.optString("username")
                nameList.add(o.getString("name") + if (uname.isNotEmpty()) " (@$uname)" else "")
            }
            ids = idList
            names = nameList
            lv.adapter = ArrayAdapter(this@BotSelectActivity, android.R.layout.simple_list_item_1, names)
            if (names.isEmpty()) {
                Toast.makeText(this@BotSelectActivity, "هیچ باتی پیدا نشد؛ اول توی سروش یک پیام به بات بفرست", Toast.LENGTH_LONG).show()
            }
        }
    }
}
