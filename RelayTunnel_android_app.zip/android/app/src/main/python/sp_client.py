#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
پل پایتون (زیر Chaquopy) برای ورود به حساب شخصی سروش و ارسال/دریافت فریم‌های تانل.
منطق لاگین و استفاده از کتابخانه عیناً از main19.py (SPUser) گرفته شده، چون همان‌جا
امتحان‌شده و جواب داده. اینجا فقط خروجی ساده‌تر (دیکشنری/رشته) برمی‌گردانیم چون از
سمت Kotlin (Chaquopy) صدا زده می‌شود.

هیچ تابعی موقع import اجرا نمی‌شود؛ Kotlin هر کدام را صریح صدا می‌زند.
"""
import asyncio, importlib, importlib.util, json, logging, os, subprocess, sys, threading, time


_pylogs = []
_pylogs_lock = threading.Lock()


def _log(msg):
    """لاگ پایتون -> لاگ داخل اپ (برچسب PYDBG)."""
    try:
        from java import jclass
        jclass("com.relaytunnel.app.AppLog").INSTANCE.add("PYDBG", str(msg)[:300])
    except Exception:
        with _pylogs_lock:
            _pylogs.append(str(msg)[:300])
            if len(_pylogs) > 300:
                del _pylogs[:100]


class _AppLogHandler(logging.Handler):
    def emit(self, record):
        try:
            _log(record.name + ": " + record.getMessage())
        except Exception:
            pass


_root_logger = logging.getLogger()
_root_logger.addHandler(_AppLogHandler())
_root_logger.setLevel(logging.WARNING)

SP_LIBS = ("nsplusthon", "splusthon", "samyarpy")

_state_lock = threading.Lock()
_loop = None
_client = None
_sp_mod = [None]
_sp_name = [None]
_phone = None
_code_hash = None


def _files_dir():
    # Chaquopy از قبل chaquopy.AndroidPlatform.files_dir را set می‌کند؛ اگر ست نشده بود cwd
    return os.environ.get("RELAY_FILES_DIR", os.getcwd())


def _session_path():
    return os.path.join(_files_dir(), "sp_session.txt")


def _load_session():
    try:
        with open(_session_path(), encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def _save_session(s):
    with open(_session_path(), "w", encoding="utf-8") as f:
        f.write(s or "")


def _digits(s):
    return (s or "").translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"))


def _norm_phone(raw):
    d = "".join(ch for ch in _digits(raw) if ch.isdigit())
    if d.startswith("0098"):
        d = d[2:]
    if d.startswith("98"):
        d = "+" + d
    elif d.startswith("0"):
        d = "+98" + d[1:]
    elif not d.startswith("+"):
        d = "+98" + d
    return d


def _get_loop():
    global _loop
    with _state_lock:
        if _loop is None:
            _loop = asyncio.new_event_loop()
            threading.Thread(target=_loop.run_forever, daemon=True).start()
    return _loop


def _run(coro_fn, *a, timeout=180):
    import concurrent.futures
    fut = asyncio.run_coroutine_threadsafe(coro_fn(*a), _get_loop())
    try:
        return fut.result(timeout)
    except concurrent.futures.TimeoutError:
        fut.cancel()   # کار معلق در صف باقی نماند
        raise RuntimeError("مهلت تمام شد")


def _ensure_lib():
    if _sp_mod[0]:
        return _sp_mod[0]
    last = None
    for name in SP_LIBS:
        try:
            if not importlib.util.find_spec(name):
                continue
            mod = importlib.import_module(name)
            sess = importlib.import_module(name + ".sessions")
            _sp_mod[0] = (mod, sess.StringSession)
            _sp_name[0] = name
            return _sp_mod[0]
        except Exception as e:
            last = e
    raise RuntimeError(f"هیچ‌کدام از کتابخانه‌های سروش نصب نیستند (pip baid nsplusthon را در build.gradle چک کنی): {last}")


def diag():
    try:
        _ensure_lib()
        return "OK: " + str(_sp_name[0])
    except Exception as e:
        return "FAIL: " + str(e)[:300]


async def _client_connected():
    global _client
    mod, SS = _ensure_lib()
    if _client is None:
        sess = SS(_load_session())
        _client = mod.SoroushClient(sess)
    if not _client.is_connected():
        _log("اتصال کلاینت سروش شروع شد...")
        t = time.time()
        await _client.connect()
        _log("اتصال برقرار شد (%.1fs)" % (time.time() - t))
    return _client


# ---------------------------------------------------------------- عمومی


async def _a_send_code(phone):
    global _phone, _code_hash
    c = await _client_connected()
    if await c.is_user_authorized():
        return json.dumps({"ok": True, "already": True})
    r = await c.send_code_request(phone)
    _phone = phone
    _code_hash = getattr(r, "phone_code_hash", None)
    return json.dumps({"ok": True, "already": False})


def send_code(phone_raw):
    try:
        return _run(_a_send_code, _norm_phone(phone_raw), timeout=240)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


async def _a_sign_in(code, password):
    c = await _client_connected()
    try:
        if password:
            await c.sign_in(password=password)
        else:
            if not _phone:
                raise RuntimeError("اول «ارسال کد» را بزن")
            kw = {"phone_code_hash": _code_hash} if _code_hash else {}
            await c.sign_in(_phone, code, **kw)
    except Exception as e:
        if type(e).__name__ == "SessionPasswordNeededError":
            return json.dumps({"ok": False, "need_password": True})
        raise
    _save_session(c.session.save())
    me = await c.get_me()
    return json.dumps({"ok": True, "user_id": str(getattr(me, "id", ""))})


def sign_in(code, password=""):
    try:
        return _run(_a_sign_in, "".join(ch for ch in _digits(code) if ch.isdigit()), password, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


async def _a_is_logged_in():
    try:
        c = await _client_connected()
        return await c.is_user_authorized()
    except Exception:
        return False


def is_logged_in():
    try:
        return bool(_run(_a_is_logged_in, timeout=60))
    except Exception:
        return False


async def _a_list_bots():
    c = await _client_connected()
    if not await c.is_user_authorized():
        raise RuntimeError("اول وارد حساب شو")
    out = []
    async for d in c.iter_dialogs(limit=300):
        ent = d.entity
        if getattr(ent, "bot", False):
            out.append({
                "id": str(d.id),
                "name": str(getattr(ent, "first_name", None) or getattr(d, "name", None) or d.id)[:60],
                "username": getattr(ent, "username", "") or "",
            })
    return json.dumps({"ok": True, "bots": out})


def list_bots():
    try:
        return _run(_a_list_bots, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


# ------------------------------------------------------------ فریم‌های تانل
# هر فریم یک خط JSON است: {"id": شمارنده صعودی، "data": base64(bytes)}
# فریم‌های کوچک به صورت پیام متنی و بزرگ‌تر از MAX_TEXT به صورت فایل txt فرستاده می‌شوند
# تا به محدودیت طول پیام سروش نخوریم.

MAX_TEXT = 3500


_ent_cache = {}


def drain_logs():
    """Kotlin این را هر ثانیه صدا می‌زند تا لاگ‌های پایتون در لاگ اپ دیده شود."""
    with _pylogs_lock:
        out = list(_pylogs)
        _pylogs.clear()
    return json.dumps(out, ensure_ascii=False)


async def _st(name, coro, t=30, verbose=True):
    """اجرای یک مرحله با timeout و لاگ زمان؛ تا گیر کردن بی‌صدا نداشته باشیم."""
    t0 = time.time()
    if verbose:
        _log(f"{name} ...")
    try:
        r = await asyncio.wait_for(coro, t)
    except asyncio.TimeoutError:
        _log(f"{name} TIMEOUT بعد از {t}s")
        raise RuntimeError(f"timeout در مرحله {name}")
    except Exception as e:
        _log(f"{name} خطا: {type(e).__name__}: {str(e)[:150]}")
        raise
    dt = time.time() - t0
    if verbose or dt > 2:
        _log(f"{name} OK ({dt:.1f}s)")
    return r


async def _find_ent(c, key):
    async for d in c.iter_dialogs(limit=300):
        if str(d.id) == key:
            return d.entity
    return None


async def _get_ent(c, bot_id, verbose=True):
    """entity بات را فقط یک بار پیدا می‌کنیم (iter_dialogs سنگین است)."""
    key = str(bot_id)
    ent = _ent_cache.get(key)
    if ent is not None:
        return ent
    ent = await _st("find_bot", _find_ent(c, key), 40, verbose)
    if ent is not None:
        _ent_cache[key] = ent
    return ent


# ------------------------------------------------------------------
# آپلود فایل در سروش: send_file معمولی خطای RPC 422 (FILE_REQUEST_RECEIVED_ON_CONNECTION_SERVER) می‌دهد.
# راه‌حل (از main19.py): یک اتصال MTProto جدا به هاست رسانه (im-server-1.splus.ir) با همان auth_key،
# اولین درخواست با InitConnection(params={"connection":"upload"}) فرستاده می‌شود، بعد فایل با handle ارسال می‌شود.
# ------------------------------------------------------------------
UPLOAD_HOST = "im-server-1.splus.ir"


class UploadSetupError(Exception):
    pass


def _json_params(types, profile):
    def _jv(v):
        if isinstance(v, bool):
            return types.JsonBool(v)
        if isinstance(v, (int, float)):
            return types.JsonNumber(float(v))
        return types.JsonString(str(v))
    return types.JsonObject([types.JsonObjectValue(k, _jv(v)) for k, v in profile])


async def _upload_media(c, path, mode, host):
    import copy, hashlib
    pk = _sp_name[0]
    pb = importlib.import_module(pk + ".client.plusbaseclient")
    types = importlib.import_module(pk + ".tl.types")
    custom = importlib.import_module(pk + ".tl.custom")
    utils = importlib.import_module(pk + ".utils")
    helpers = importlib.import_module(pk + ".helpers")
    funcs = pb.functions

    size = os.path.getsize(path)
    is_big = size > 10 * 1024 * 1024
    part_size = min(int(utils.get_appropriated_part_size(size) * 1024), 512 * 1024)
    count = max(1, (size + part_size - 1) // part_size)
    params = _json_params(types, (("connection", "upload"),))
    file_id = helpers.generate_random_long()
    name = os.path.basename(path)
    md5 = None if is_big else hashlib.md5()

    sender = None
    try:
        dc_id = c.session.dc_id
        dc = await c._get_dc(dc_id)
        key = c._sender.auth_key if mode == "shared" else None
        auth = await c(funcs.auth.ExportAuthorizationRequest(dc_id)) if mode == "export" else None
        sender = pb.MTProtoSender(key, loggers=c._log)
        await sender.connect(c._connection(host or dc.ip_address, dc.port, dc.id,
                                           loggers=c._log, proxy=c._proxy, local_addr=c._local_addr))
        if auth is not None:
            init = copy.copy(c._init_request)
            init.query = funcs.auth.ImportAuthorizationRequest(id=auth.id, bytes=auth.bytes)
            await sender.send(funcs.InvokeWithLayerRequest(pb.LAYER, init))
    except Exception as e:
        if sender is not None:
            try:
                await sender.disconnect()
            except Exception:
                pass
        raise UploadSetupError(f"{type(e).__name__}: {e}") from e

    try:
        first = True
        with open(path, "rb") as f:
            for i in range(count):
                part = f.read(part_size)
                if is_big:
                    req = funcs.upload.SaveBigFilePartRequest(file_id, i, count, part)
                else:
                    md5.update(part)
                    req = funcs.upload.SaveFilePartRequest(file_id, i, part)
                if first:  # اولین درخواست باید با InitConnection(params) همراه باشد
                    init = copy.copy(c._init_request)
                    init.params = params
                    init.query = req
                    req = funcs.InvokeWithLayerRequest(pb.LAYER, init)
                    first = False
                if not await sender.send(req):
                    raise RuntimeError(f"بخش {i} آپلود نشد")
    finally:
        try:
            await sender.disconnect()
        except Exception:
            pass

    if is_big:
        return types.InputFileBig(file_id, count, name)
    return custom.InputSizedFile(file_id, count, name, md5=md5, size=size)


async def _send_file_media(c, ent, path):
    handle, errs = None, []
    for mode in ("shared", "export"):
        try:
            handle = await _st(f"upload({mode})", _upload_media(c, path, mode, UPLOAD_HOST), 60)
            break
        except UploadSetupError as e:
            errs.append(f"{mode}: {str(e)[:120]}")
            _log(f"روش {mode} ناموفق: {str(e)[:150]}")
        except Exception as e:
            errs.append(f"{mode}: {type(e).__name__}")
            _log(f"آپلود {mode} خطا: {type(e).__name__}: {str(e)[:150]}")
    if handle is None:
        # آخرین راه: آپلود معمولی کتابخانه
        try:
            await _st("send_file(normal)", c.send_file(ent, path, force_document=True), 60)
            return
        except Exception as e:
            raise RuntimeError("آپلود ناموفق: " + " | ".join(errs) + f" | normal: {str(e)[:100]}") from e
    last = None
    for attempt in range(3):
        try:
            await _st("send_file(handle)", c.send_file(ent, handle, force_document=True), 30)
            return
        except Exception as e:
            last = e
            await asyncio.sleep(2)
    raise RuntimeError(f"آپلود شد ولی ارسال به مقصد ناموفق بود: {str(last)[:200]}")


# True: همه‌ی فریم‌ها (حتی کوتاه) به‌صورت فایل txt با روش آپلود رسانه فرستاده می‌شوند
ALWAYS_FILE = True
_text_broken = [False]


async def _do_send_frame(bot_id, payload_b64):
    c = await _st("connect", _client_connected(), 30)
    if not await _st("authorized", c.is_user_authorized(), 20):
        raise RuntimeError("اکانت وارد نشده")
    ent = await _get_ent(c, bot_id)
    if ent is None:
        raise RuntimeError("بات انتخابی پیدا نشد؛ دوباره انتخابش کن")
    text = payload_b64

    # پیام متنی (اگر کوچک است و قبلاً گیر نکرده)
    if (not ALWAYS_FILE) and len(text) <= MAX_TEXT and not _text_broken[0]:
        for attempt in (1, 2):
            try:
                await _st(f"send_message({len(text)})", c.send_message(ent, text), 12)
                return json.dumps({"ok": True})
            except RuntimeError as e:
                if "timeout" not in str(e):
                    raise
                if attempt == 1:
                    await _reconnect(c)   # شاید اتصال مرده بوده؛ یک بار دوباره امتحان کن
                else:
                    _text_broken[0] = True
                    _log("send_message بعد از reconnect هم جواب نداد؛ از این به بعد با فایل فرستاده می‌شود")

    # فایل txt با روش آپلود رسانه (همان روش پروژه‌ی main19)
    path = os.path.join(_files_dir(), f"out_{int(time.time()*1000)}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    try:
        await _st(f"send_file({len(text)})", _send_file_media(c, ent, path), 150)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass
    return json.dumps({"ok": True})


async def _a_test_send(bot_id):
    """تست ایزوله: فقط ارسال فایل txt (روش آپلود رسانه) با دو محتوای مختلف."""
    res = []
    c = await _st("test.connect", _client_connected(), 30)
    ent = await _get_ent(c, bot_id)
    cases = [
        ("txt ساده", "relay test file"),
        ("txt فریم JSON", json.dumps({"v": 1, "frames": [{"t": "C", "id": 9004}]})),
    ]
    for name, content in cases:
        path = os.path.join(_files_dir(), f"test_{int(time.time()*1000)}.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        t0 = time.time()
        try:
            await _st("test:" + name, _send_file_media(c, ent, path), 60)
            res.append(f"{name}: OK ({time.time()-t0:.1f}s)")
        except Exception as e:
            res.append(f"{name}: ✗ {str(e)[:120]}")
        finally:
            try:
                os.remove(path)
            except Exception:
                pass
    return json.dumps({"ok": True, "result": res}, ensure_ascii=False)


def test_send(bot_id):
    try:
        return _run(_a_test_send, bot_id, timeout=120)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


_io_lock = [None]


def _lock():
    if _io_lock[0] is None:
        _io_lock[0] = asyncio.Lock()
    return _io_lock[0]


async def _reconnect(c):
    """اتصال WebSocket بعد از idle ممکن است بسته شده باشد؛ قطع و وصل اجباری."""
    _log("reconnect اجباری ...")
    try:
        await asyncio.wait_for(c.disconnect(), 10)
    except Exception as e:
        _log(f"disconnect: {type(e).__name__}")
    await _st("reconnect.connect", c.connect(), 30)


async def _a_send_frame(bot_id, payload_b64):
    async with _lock():
        return await _do_send_frame(bot_id, payload_b64)


async def _a_poll(bot_id):
    async with _lock():
        return await _do_poll(bot_id)


def send_frame(bot_id, payload_b64):
    try:
        return _run(_a_send_frame, bot_id, payload_b64, timeout=170)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


_last_seen_id = [0]


async def _collect_new(c, ent):
    out = []
    async for msg in c.iter_messages(ent, min_id=_last_seen_id[0], limit=50):
        if msg.id <= _last_seen_id[0]:
            continue
        if msg.id > _last_seen_id[0]:
            _last_seen_id[0] = msg.id
        if msg.out:
            continue  # پیام‌های خودمان را نادیده بگیر
        text = msg.raw_text or ""
        if (not text) and msg.document:
            local = os.path.join(_files_dir(), f"in_{msg.id}.txt")
            await msg.download_media(file=local)
            try:
                with open(local, encoding="utf-8") as f:
                    text = f.read()
            finally:
                try:
                    os.remove(local)
                except Exception:
                    pass
        if text:
            out.append(text)
    return out


async def _do_poll(bot_id):
    c = await _st("poll.connect", _client_connected(), 30, False)
    if not await _st("poll.authorized", c.is_user_authorized(), 20, False):
        raise RuntimeError("اکانت وارد نشده")
    ent = await _get_ent(c, bot_id, False)
    if ent is None:
        raise RuntimeError("بات انتخابی پیدا نشد")
    if _last_seen_id[0] == 0:
        # اولین poll: پیام‌های قدیمی چت را نادیده بگیر
        last = await _st("poll.baseline", c.get_messages(ent, limit=1), 30)
        _last_seen_id[0] = (last[0].id if last else 0) or 1
        _log(f"poll baseline id={_last_seen_id[0]}")
        return json.dumps({"ok": True, "frames": []})
    out = await _st("poll.fetch", _collect_new(c, ent), 60, False)
    if out:
        _log(f"poll: {len(out)} پیام جدید")
    return json.dumps({"ok": True, "frames": out})


def poll(bot_id):
    try:
        return _run(_a_poll, bot_id, timeout=60)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)[:300]})


def logout():
    global _client
    try:
        if _client is not None:
            _run(_client.disconnect, timeout=20)
    except Exception:
        pass
    _client = None
    try:
        os.remove(_session_path())
    except Exception:
        pass
    return json.dumps({"ok": True})
